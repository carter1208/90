BasicGame.mainGame = function(game) {};
var crateSprite , spriteB = null, spriteA, btn_play, btn_retry, lock, gameOver, h, col;
var caption1, caption2;
var arrBox = [];
BasicGame.mainGame.prototype = {
	preload: function() {
	},
	create: function() {
		this.game.physics.startSystem(Phaser.Physics.BOX2D);
		this.game.physics.box2d.setBoundsToWorld();
		this.game.physics.box2d.gravity.y = 500;		
		var background = this.game.add.tileSprite(0, 0, 800, 600, 'background');
		var groundSprite = this.game.add.sprite(this.game.world.centerX, this.game.world.height, "ground");
		this.game.physics.box2d.enable(groundSprite);
    	groundSprite.body.static = true;		
		this.game.input.onDown.add(addCrate, this);	
		this.game.input.addMoveCallback(mouseDragMove, this);
		this.game.input.onUp.add(mouseDragEnd, this);
		// caption1 = this.game.add.text(5, 25, 'Last collision normal impulse: -', { fill: '#ffffff', font: '14pt Arial' });
		// caption2 = this.game.add.text(5, 45, 'Last collision normal impulse: -', { fill: '#ffffff', font: '14pt Arial' });
		btn_play = this.game.add.button(this.game.world.centerX, 300, 'btn_play', this.startGame, this, 1, 0, 1);
		btn_retry = this.game.add.button(this.game.world.centerX, 300, 'btn_retry', this.startGame, this, 1, 0, 1);
        btn_play.anchor.set(0.5);
        btn_retry.anchor.set(0.5);
        btn_retry.visible = false;
		spriteA = this.game.add.sprite(this.game.world.centerX, -500, 'crate');
		this.game.physics.box2d.enable(spriteA);
		spriteA.body.static = true;
    },
	update: update,
	render: render,
	startGame: function(){		
		col = 0;
		h = 60;
		btn_play.visible = false;
		btn_retry.visible = false;
		spriteB = this.game.add.sprite(140, h, 'crate');
		arrBox.push(spriteB);
		gameOver = false;
		this.game.physics.box2d.enable(spriteB); 
		this.game.physics.box2d.distanceJoint(spriteA, spriteB);
	}	
}

function addCrate(e){	
	this.game.physics.box2d.mouseDragStart(this.game.input.mousePointer);
	if(btn_play.visible || btn_retry.visible || lock){
		return;
	}	
	lock = true;
	if(spriteB != null){
		spriteB.destroy();	
	}		
	crateSprite = this.game.add.sprite(spriteB.x, spriteB.y, "crate");
	arrBox.push(crateSprite);
	this.game.physics.box2d.enable(crateSprite);
	crateSprite.body.setRectangle(80, 80, 0, 0, 0);
	crateSprite.body.setCategoryPostsolveCallback(0x8000, callback, this);	
	setTimeout(function() {
		spriteB = null; 
		lock = false;
		col++;
		if(col > 3){
			h -= 40;
		}
	}, 1500);
}

function callback(body1, body2, fixture1, fixture2, contact, impulseInfo) {  
	// caption1.text = 'Last collision normal impulse:  x:' + h +  ":::" + Math.abs(crateSprite.body.angle) + "::::" + Math.floor(crateSprite.x);
	// caption2.text = 'Last collision tangent impulse: ' + h;
	
	if(Math.abs(crateSprite.body.angle) < 10 && Math.floor(this.game.world.centerX + 30) > Math.floor(crateSprite.x) > Math.floor(this.game.world.centerX - 30)){
		return;
	}
	setTimeout(function() {    
		btn_retry.visible = true;
		gameOver = true;
	}, 250);
	setTimeout(createChild, 300);
}

function update(){
	if(spriteB == null && btn_play.visible == false){			
		spriteB = this.game.add.sprite(140, h, 'crate');
		arrBox.push(spriteB);
		this.game.physics.box2d.enable(spriteB); 
		this.game.physics.box2d.distanceJoint(spriteA, spriteB);		
	}
	if(gameOver){
		createChild();
	}
}

function mouseDragMove() {    
    this.game.physics.box2d.mouseDragMove(this.game.input.mousePointer);    
}

function mouseDragEnd() {this.game.physics.box2d.mouseDragEnd(); }

function createChild() {
	if(arrBox.length > 0 ){
		for(var i =0; i < arrBox.length; i++){
			arrBox[i].destroy();
		}
	}
}

function render() {
    if (this.game.paused)
    {
        update();
    }
}