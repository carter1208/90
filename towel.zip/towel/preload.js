var BasicGame = {};
BasicGame.Preloader = function(game) {};
BasicGame.Preloader.prototype = {
	preload: function() {
		this.game.load.spritesheet("btn_play", "btn_play.png");
		this.game.load.spritesheet("btn_retry", "btn_retry.png");
		this.game.load.spritesheet("crate", "crate.png");
		this.game.load.image("ground", "ground.png");
	},
	create: function() {
    },       
    update:function(){		
		this.game.state.start('mainGame');
	}
};