var BasicGame = {};
BasicGame.Preloader = function(game) {};
BasicGame.Preloader.prototype = {
	preload: function() {
		this.game.load.spritesheet("btn_play", "img/btn_play.png");
		this.game.load.spritesheet("btn_retry", "img/btn_retry.png");
		this.game.load.spritesheet("crate", "img/crate.png");
		this.game.load.image("ground", "img/ground.png");
		this.game.load.image("background", "img/background.png");
	},
	create: function() {
    },       
    update:function(){		
		this.game.state.start('mainGame');
	}
};